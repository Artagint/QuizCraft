package com.example.quizcraft

class TakeQuizActivity {
}